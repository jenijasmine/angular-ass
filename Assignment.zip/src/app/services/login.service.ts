import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


const httpOptions={
  headers: new HttpHeaders({
    'Content-type': 'application/json',
    'Access-Control-Allow-Origin':'*'
  })
};
@Injectable({
  providedIn: 'root'
})

export class LoginService {

  URL ='http://localhost:3000/users'
  constructor(private http: HttpClient) { }


  loginuser(name,password) {
   let userdata= JSON.parse(JSON.stringify(this.http.get(this.URL,httpOptions)));
   userdata.forEach(element => {
     if(element.username===name && element.password===password){


     }
     else{
       alert("Incorrect username & password");
     }

   });

  }
}
